import { atom  } from "recoil";


export const ticketState = atom({
    key:'ticketState', 
    default: [], 
  });

  