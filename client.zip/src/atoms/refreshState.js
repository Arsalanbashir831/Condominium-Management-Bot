import { atom  } from "recoil";

export const refreshState = atom({
    key:'refresh', 
    default: false, 
  });

  