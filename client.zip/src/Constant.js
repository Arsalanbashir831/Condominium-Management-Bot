export const BACKEND_URL='http://localhost:8080'
// http://localhost:8080
//https://condominium-management-backend.onrender.com